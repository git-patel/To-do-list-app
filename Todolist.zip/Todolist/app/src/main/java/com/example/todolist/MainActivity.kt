package com.example.todolist

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    lateinit var add: Button
    lateinit var item : EditText
    lateinit var listView : ListView


var itemList = ArrayList<String>()

var fileHelper = FileHelper()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        add = findViewById(R.id.button)
        item = findViewById(R.id.addlist)
        listView = findViewById(R.id.listview)



   itemList = fileHelper.readData(this )
var arrayAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,android.R.id.text1,itemList)

        listView.adapter = arrayAdapter

        add.setOnClickListener{
            var itemName : String = item.text.toString()
            itemList.add(itemName)
            item.setText("")
            fileHelper.writeData(itemList,applicationContext)
            arrayAdapter.notifyDataSetChanged()
        }



        listView.setOnItemClickListener { adapterView, view, position, l ->

            var alertDilog = AlertDialog.Builder(this@MainActivity)

            alertDilog.setTitle("THAY GYU KAM")
                .setMessage("KAM PURU KARE YU KE NAY")
                .setIcon(R.drawable.warning)
                .setCancelable(false)
                .setNegativeButton("NA", DialogInterface.OnClickListener {
                    dialogInterface , i  -> dialogInterface.cancel()

                })
                alertDilog.setPositiveButton("HA", DialogInterface.OnClickListener {
                     dialogInterface , i ->
                    itemList.removeAt(position)
                    arrayAdapter.notifyDataSetChanged()
                    fileHelper.writeData(itemList,applicationContext)
                })

            alertDilog.create().show()
        }





    }
}